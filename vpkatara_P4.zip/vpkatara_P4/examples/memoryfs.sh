#!/usr/bin/env bash

cd "`dirname "$0"`"
./run.sh net.fusejna.examples.MemoryFS "$@"
